const FeedbackData = [
{
    id : '1',
    rating: 10,
    text : 'Lorem agna aliqua.Snisi ut aliquip ex ea commodo consequat.'
},
{
    id : '2',
    rating:5 ,
    text : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed gna aliqua.'
},{
    id : '3',
    rating:9 ,
    text : 'Lorem ipsum dolort aliquip ex ea commodo consequat.'
},{
    id : '4',
    rating: 8,
    text : 'Lorem dunt  quis nostrud exercitation consequat.'
}
]

export default FeedbackData;